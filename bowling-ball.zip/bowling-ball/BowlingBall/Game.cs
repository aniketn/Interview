﻿namespace BowlingBall
{
    public class Game
    {
        private int[] rolls = new int[20];
        private int cur_Roll_Attempt = 0;

        //Verify if all 10 pins are being knocked down 
        private bool IsStrike(int rollIndex)
        {
            return rolls[rollIndex] == 10;
        }

        /// <summary>
        /// To get frame score for strike
        /// </summary>
        /// <param name="rollIndex">Roll Attempts</param>
        /// <returns>Frame Score</returns>
        private int GetStrikeScore(int rollIndex)
        {
            return rolls[rollIndex] + rolls[rollIndex + 1] + rolls[rollIndex + 2];
        }

        /// <summary>
        /// To get frame score if the frame is neither Stirke nor Spare
        /// </summary>
        /// <param name="rollIndex">Roll Attempts</param>
        /// <returns>Frame Score</returns>
        private int GetStandardScore(int rollIndex)
        {
            return rolls[rollIndex] + rolls[rollIndex + 1];
        }

        //Verify if all 10 pins are being knocked down in 2 attempts
        private bool IsSpare(int rollIndex)
        {
            return rolls[rollIndex] + rolls[rollIndex + 1] == 10;
        }

        /// <summary>
        /// To get Frame score if the the frame is Spare i.e. knocked down all 10 pins in 2 attempts
        /// </summary>
        /// <param name="rollIndex">Roll Attempts</param>
        /// <returns>Frame Score</returns>
        private int GetSpareScore(int rollIndex)
        {
            return rolls[rollIndex] + rolls[rollIndex + 1] + rolls[rollIndex + 2];
        }

        public void Roll(int pins)
        {
            rolls[cur_Roll_Attempt++] = pins;
        }

        /// <summary>
        /// Calculate Final Score
        /// </summary>
        /// <returns>Final Score</returns>
        public int GetScore()
        {
            var score = 0;
            var rollIndex = 0;
            for (int frame = 0; frame < 10; frame++)
            {
                if (IsSpare(rollIndex))
                {
                    score += GetSpareScore(rollIndex);
                    rollIndex += 2;
                }
                else if (IsStrike(rollIndex))
                {
                    score += GetStrikeScore(rollIndex);
                    rollIndex++;
                }
                else
                {
                    score += GetStandardScore(rollIndex);
                    rollIndex += 2;
                }
            }
            return score;
        }
    }
}
