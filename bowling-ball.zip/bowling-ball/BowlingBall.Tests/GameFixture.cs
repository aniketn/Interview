﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace BowlingBall.Tests
{
    [TestClass]
    public class GameFixture
    {
        private Game game;

        [TestInitialize]
        public void Initialize()
        {
            game = new Game();
        }

        [TestMethod]
        public void Bowling_With_Strike_Spare_Standard_Attempts()
        {
            game.Roll(10);
            game.Roll(9);
            game.Roll(1);
            game.Roll(5);
            game.Roll(5);
            game.Roll(7);
            game.Roll(2);
            game.Roll(10);
            game.Roll(10);
            game.Roll(10);
            game.Roll(9);
            game.Roll(0);
            game.Roll(8);
            game.Roll(2);
            game.Roll(9);
            game.Roll(1);
            game.Roll(10);
            Assert.AreEqual(187, game.GetScore());
        }

        [TestMethod]
        public void Gutter_Game_Score_Should_Be_Zero_Test()
        {
            RollMany(0, 20);
            Assert.AreEqual(0, game.GetScore());
        }

        [TestMethod]
        public void Can_Roll_All_Ones()
        {
            RollMany(1, 20);
            Assert.AreEqual(20, game.GetScore());
        }

        [TestMethod]
        public void Can_Roll_Spare()
        {
            game.Roll(5);
            game.Roll(5);
            game.Roll(3);
            RollMany(0, 17);
            Assert.AreEqual(16, game.GetScore());
        }

        [TestMethod]
        public void Can_Roll_Strike()
        {
            game.Roll(10);
            game.Roll(3);
            game.Roll(4);
            RollMany(0, 16);
            Assert.AreEqual(24, game.GetScore());
        }

        [TestMethod]
        public void Can_Roll_Perfect_Game()
        {
            RollMany(10, 12);
            Assert.AreEqual(300, game.GetScore());
        }

        private void RollMany(int pins, int times)
        {
            for (int i = 0; i < times; i++)
            {
                game.Roll(pins);
            }
        }
    }
}
